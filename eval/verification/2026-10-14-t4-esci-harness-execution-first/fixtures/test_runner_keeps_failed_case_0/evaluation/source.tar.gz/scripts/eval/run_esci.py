"""ESCI 开发档评测入口：人工候选排序、全库召回与硬约束，保留实际策略证据。"""
from __future__ import annotations

import argparse
import asyncio
from collections import defaultdict
from dataclasses import replace
from datetime import datetime
import gzip
import json
import math
from pathlib import Path
import subprocess
import time
from zoneinfo import ZoneInfo

from app.application.usecases.catalog_search import CatalogSearchUseCase, tokenize
from app.domain.catalog.ports.retrieval_ports import EmbeddingClient
from app.domain.catalog.product_search_spec import ProductSearchSpec
from app.infrastructure.embedding.openai_embedding_client import OpenAIEmbeddingClient
from app.infrastructure.persistence.in_memory_repositories import InMemoryProductRepository
from app.infrastructure.persistence.seed_products import _product_from_record
from app.infrastructure.rerank.factory import create_reranker
from app.infrastructure.retrieval.bm25 import bm25_rank, reciprocal_rank_fusion
from app.infrastructure.settings import load_settings
from app.infrastructure.vector.index_bootstrap import bootstrap_product_index
from app.infrastructure.vector.qdrant_product_index import QdrantProductIndex
from scripts.esci.download import ROOT, fingerprint
from scripts.esci.prepare import json_line
from scripts.eval.hard_constraints import find_hit_constraint_violations
from scripts.eval.metrics import ESCI_GAINS, graded_ndcg_at_k, judged_at_k, precision_at_k, recall_at_k

STRATEGIES=('keyword_2gram','bm25','embedding_only','embedding_rerank','hybrid_only','hybrid_rerank')


def read_rows(path: Path) -> list[dict]:
    opener=gzip.open if path.suffix=='.gz' else open
    with opener(path,'rt',encoding='utf-8') as stream:
        return [json.loads(line) for line in stream if line.strip()]


def validate_cases(cases: dict[str,list[dict]], products: list) -> None:
    ids={p.product_id for p in products}
    if not products or len(ids)!=len(products):
        raise ValueError('商品目录为空或编号重复')
    if not cases or any(not rows for rows in cases.values()):
        raise ValueError('ESCI 评测组或查询为空')
    for kind,rows in cases.items():
        if kind not in ('ranking','retrieval','constraints','crosslingual'):
            raise ValueError(f'未知 ESCI 评测组：{kind}')
        seen=set()
        for row in rows:
            key=row['locale'],row['query_id']
            if key in seen or row['locale'] not in ('us','es','jp') or not isinstance(row['query'],str) or not row['query'].strip():
                raise ValueError(f'查询编号、站点或文本无效：{kind}/{key}')
            seen.add(key)
            if kind=='constraints':
                referenced=row['relevant_product_ids']
                ProductSearchSpec(normalized_query=row['query'],ship_to=row['ship_to'],price_max_major=row['price_max_major'],
                    target_currency=row['target_currency'],top_k=5)
                if row['in_stock'] is not True or type(row['expected_empty']) is not bool:
                    raise ValueError('硬约束用例需明确库存与空结果要求')
            else:
                pairs=[(r['product_id'],r['label']) for r in row['candidates']] if kind=='ranking' else list(row['labels'].items())
                referenced=[product_id for product_id,_ in pairs]
                if not pairs or len(set(referenced))!=len(referenced) or any(label not in ESCI_GAINS for _,label in pairs):
                    raise ValueError(f'人工标注重复、为空或等级无效：{kind}/{key}')
            if set(referenced)-ids:
                raise ValueError(f'评测引用了目录外的商品：{kind}/{key}')


class FrozenQueryEmbedding(EmbeddingClient):
    """所有策略复用同一批查询向量，查询编码的耗时单独记录。"""
    def __init__(self, vectors):
        self.vectors=vectors

    async def embed(self, text):
        return self.vectors[text]

    async def embed_batch(self, texts):
        return [self.vectors[text] for text in texts]


async def rank_candidates(case, strategy, products, usecase, embedder, vector_index, weights):
    """只给人工候选打分；BM25 的文档频率及平均长度取自完整目录。"""
    by_id={p.product_id:p for p in products}
    candidates=[by_id[row['product_id']] for row in case['candidates']]
    spec=ProductSearchSpec(normalized_query=case['query'])
    lexical=[];dense=[]
    if strategy=='keyword_2gram':
        terms=tokenize(case['query'])
        ranked=[(usecase._keyword_score(terms,p,spec),p) for p in candidates]
    else:
        if strategy=='bm25' or strategy.startswith('hybrid'):
            scores={p.product_id:score for score,p in bm25_rank(case['query'],products)}
            lexical=sorted([(scores.get(p.product_id,0.0),p) for p in candidates],key=lambda pair:(-pair[0],pair[1].product_id))
        if strategy not in ('bm25','keyword_2gram'):
            ids=[p.product_id for p in candidates]
            hits=await vector_index.search_filtered(await embedder.embed(case['query']),top_n=len(ids),product_ids=ids)
            if hits is None or len(hits)!=len(ids) or {h.product_id for h in hits}!=set(ids) or any(not math.isfinite(h.score) for h in hits):
                raise RuntimeError('人工候选向量缺失或分数无效，停止排序评测')
            dense=sorted([(h.score,by_id[h.product_id]) for h in hits],key=lambda pair:(-pair[0],pair[1].product_id))
        ranked=lexical if strategy=='bm25' else reciprocal_rank_fusion(lexical,dense,weights=weights) if strategy.startswith('hybrid') else dense
    if strategy.endswith('_rerank'):
        ranked=await usecase._rerank(spec,ranked)
    return [p.product_id for _,p in sorted(ranked,key=lambda pair:(-pair[0],pair[1].product_id))]


def recall_metrics(retrieved: list[str], labels: dict[str,str]) -> dict:
    exact=[product_id for product_id,label in labels.items() if label=='E']
    return {'recall_at_10':recall_at_k(retrieved,exact,10),'recall_at_50':recall_at_k(retrieved,exact,50),
        'ndcg_at_10':graded_ndcg_at_k(retrieved,labels,10),'judged_at_10':judged_at_k(retrieved,labels,10)}


async def evaluate_cases(cases: dict, products: list, strategies: tuple, report: dict, *,
                         embedder=None, vector_index=None, reranker=None, recall_candidates=32, weights=(1.0,1.0)) -> dict:
    validate_cases(cases,products)
    if not strategies or len(set(strategies))!=len(strategies) or set(strategies)-set(STRATEGIES):
        raise ValueError('检索策略为空、重复或无效')
    report.update(status='RUNNING',samples=[],strategies={},query_encoding={'unique_queries':0,'seconds':0.0},llm_calls=0)
    active=[]
    for name in strategies:
        reason='reranker_not_configured' if name.endswith('_rerank') and reranker is None else (
            'embedding_or_index_not_configured' if name not in ('keyword_2gram','bm25') and (embedder is None or vector_index is None) else None)
        report['strategies'][name]={'status':'NOT_EXECUTED','reason':reason} if reason else {'status':'PENDING'}
        if reason is None:active.append(name)
    if any(name not in ('keyword_2gram','bm25') for name in active):
        queries=sorted({row['query'] for rows in cases.values() for row in rows})
        started=time.perf_counter();vectors=await embedder.embed_batch(queries)
        if len(vectors)!=len(queries) or any(not vector or not all(type(x) in (int,float) and math.isfinite(x) for x in vector) for vector in vectors):
            raise ValueError('查询向量数量或内容无效')
        embedder=FrozenQueryEmbedding(dict(zip(queries,vectors,strict=True)))
        report['query_encoding']={'unique_queries':len(queries),'seconds':time.perf_counter()-started}
    repo=InMemoryProductRepository(products);by_id={p.product_id:p for p in products}
    for name in active:
        report['strategies'][name]={'status':'RUNNING'}
        dense=name not in ('keyword_2gram','bm25')
        usecase=CatalogSearchUseCase(repo,embedder if dense else None,vector_index if dense else None,
            reranker if name.endswith('_rerank') else None,hybrid_enabled=name in ('bm25','hybrid_only','hybrid_rerank'),
            hybrid_lexical_weight=weights[0],hybrid_vector_weight=weights[1],recall_candidates=recall_candidates)
        for kind,rows in cases.items():
            for case in rows:
                start=time.perf_counter();errors=[];violations={};empty_ok=None
                if kind=='ranking':
                    retrieved=await rank_candidates(case,name,products,usecase,embedder,vector_index,weights)
                    labels={row['product_id']:row['label'] for row in case['candidates']}
                    metrics={'ndcg':graded_ndcg_at_k(retrieved,labels,len(labels)),
                        'ndcg_at_10':graded_ndcg_at_k(retrieved,labels,10)}
                    actual='candidate_'+name;rerank_applied=name.endswith('_rerank')
                else:
                    constrained=kind=='constraints'
                    spec=ProductSearchSpec(normalized_query=case['query'],top_k=5 if constrained else 50,
                        ship_to=case['ship_to'] if constrained else None,
                        price_max_major=case['price_max_major'] if constrained else None,
                        target_currency=case['target_currency'] if constrained else 'CNY',
                        required_material_tags=case.get('required_material_tags',[]) if constrained else [],
                        excluded_material_tags=case.get('excluded_material_tags',[]) if constrained else [])
                    result=await usecase.execute(spec)
                    retrieved=[hit['product_id'] for hit in result['hits']]
                    actual=result['recall_strategy'];rerank_applied=result['rerank_applied']
                    if dense and actual in ('keyword_2gram','bm25','bm25_rerank','local_embedding'):
                        errors.append('requested_vector_strategy_degraded')
                    if name.endswith('_rerank') and result['hits'] and not rerank_applied and actual!='exact_id_lookup':
                        errors.append('requested_reranker_not_applied')
                    if constrained:
                        empty_ok=not retrieved if case['expected_empty'] else None
                        metrics={'recall_at_5':None if case['expected_empty'] else recall_at_k(retrieved,case['relevant_product_ids'],5),
                            'precision_at_5':None if case['expected_empty'] else precision_at_k(retrieved,case['relevant_product_ids'],5)}
                        violations=find_hit_constraint_violations(result['hits'],by_id,ship_to=spec.ship_to,
                            price_max_major=spec.price_max_major,target_currency=spec.target_currency,
                            required_material_tags=spec.required_material_tags,excluded_material_tags=spec.excluded_material_tags)
                    else:
                        metrics=recall_metrics(retrieved,case['labels'])
                sample={'kind':kind,'strategy':name,'locale':case['locale'],'query_id':case['query_id'],'query':case['query'],
                    'retrieved':retrieved,'returned_count':len(retrieved),'metrics':metrics,'actual_strategy':actual,
                    'rerank_applied':rerank_applied,'elapsed_ms':(time.perf_counter()-start)*1000,
                    'violations':{product_id:sorted(reasons) for product_id,reasons in violations.items()},
                    'empty_ok':empty_ok,'execution_errors':errors}
                report['samples'].append(sample)
                if errors or violations or empty_ok is False:
                    report['strategies'][name]={'status':'FAILED'}
                    report['status']='FAILED'
                    raise RuntimeError('实际检索路径退化或硬约束结果无效，停止该策略评测')
        report['strategies'][name]={'status':'COMPLETED'}
    grouped=defaultdict(list)
    for row in report['samples']:
        for locale in ('all',row['locale']):grouped[row['kind'],row['strategy'],locale].append(row)
    report['summary']={}
    for (kind,name,locale),rows in grouped.items():
        metrics={metric:sum(values)/len(values) for metric in rows[0]['metrics']
            if (values:=[row['metrics'][metric] for row in rows if row['metrics'][metric] is not None])}
        checked=[row['empty_ok'] for row in rows if row['empty_ok'] is not None]
        summary={'queries':len(rows),'metrics':metrics,'mean_returned_count':sum(row['returned_count'] for row in rows)/len(rows),
            'constraint_violations':sum(len(row['violations']) for row in rows),
            'empty_accuracy':sum(checked)/len(checked) if checked else None,
            'actual_strategies':sorted({row['actual_strategy'] for row in rows})}
        report['summary'].setdefault(kind,{}).setdefault(name,{})[locale]=summary
    report['status']='COMPLETED'
    return report


async def run(args) -> dict:
    args.output.mkdir(parents=True,exist_ok=False)
    dataset_paths={kind:args.dataset_dir/f'{kind}-dev.jsonl' for kind in ('ranking','retrieval','constraints')}
    source_paths=sorted((ROOT/'app').rglob('*.py'))+[Path(__file__),ROOT/'scripts/eval/metrics.py',
        ROOT/'scripts/eval/hard_constraints.py',ROOT/'scripts/esci/download.py',ROOT/'scripts/esci/prepare.py',
        ROOT/'pyproject.toml',ROOT/'uv.lock']
    manifest={'started_at':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'split':'dev','status':'RUNNING',
        'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'fingerprint_method':'blake2b','source_fingerprints':{str(p.relative_to(ROOT)):fingerprint(p) for p in source_paths}}
    report={'status':'RUNNING','samples':[],'split':'dev','llm_calls':0,
        'crosslingual':{'status':'NOT_EXECUTED','reason':'derived_from_holdout_requires_frozen_parameters'},
        'holdout':{'status':'NOT_EXECUTED'},'default_strategy':{'status':'NOT_SELECTED'},
        'metric_definitions':{'gains':ESCI_GAINS,'judged_at_10':'前10条去重返回结果中有人工标注的比例，分母为实际返回数',
            'category':'查询类目用于报告，全库及硬约束检索不传类目',
            'latency':'复用固定查询向量后的检索耗时，查询编码耗时单独记录',
            'constraints':'应为空用例独立统计空结果准确率，其余用例统计Recall@5、Precision@5'}}
    vector_index=None
    (args.output/'manifest.json').write_text(json_line(manifest))
    try:
        data_paths=[args.catalog,*dataset_paths.values()]
        manifest['data_fingerprints']={str(p.resolve()):fingerprint(p) for p in data_paths}
        products=[_product_from_record(row) for row in read_rows(args.catalog)]
        cases={kind:read_rows(path) for kind,path in dataset_paths.items()}
        validate_cases(cases,products)
        if not args.strategies or len(set(args.strategies))!=len(args.strategies) or set(args.strategies)-set(STRATEGIES):
            raise ValueError('检索策略为空、重复或无效')
        settings=load_settings(require_llm_key=False)
        params={'strategies':list(args.strategies),'recall_candidates':settings.recall_candidates,
            'rrf_weights':[settings.hybrid_lexical_weight,settings.hybrid_vector_weight],'rrf_k':60,
            'full_catalog_top_k':50,'constraints_top_k':5}
        manifest['parameters']=params;report['parameters']=params
        reranker=create_reranker(settings) if any(name.endswith('_rerank') for name in args.strategies) else None
        enabled=[name for name in args.strategies if not name.endswith('_rerank') or reranker is not None]
        embedder=None
        if any(name not in ('keyword_2gram','bm25') for name in enabled):
            if not settings.embedding_api_key or not settings.embedding_base_url or not settings.embedding_model:
                raise RuntimeError('向量策略需要 EMBEDDING_BASE_URL、EMBEDDING_API_KEY 和 EMBEDDING_MODEL')
            index_settings=replace(settings,data_dir=args.index_dir,qdrant_collection='globex_products_esci_eval')
            embedder=OpenAIEmbeddingClient(index_settings);vector_index=QdrantProductIndex(index_settings)
            report['index_build']={};started=time.perf_counter()
            complete=await bootstrap_product_index(InMemoryProductRepository(products),embedder,vector_index,report=report['index_build'])
            report['index_build']['seconds']=time.perf_counter()-started
            if not complete:raise RuntimeError('ESCI 向量索引未完成，停止评测')
            manifest['embedding']={'model':settings.embedding_model,'version':settings.embedding_version,
                'dimension':settings.embedding_dim,'collection':index_settings.qdrant_collection}
        manifest['reranker']={'model':settings.reranker_model} if reranker is not None else None
        (args.output/'manifest.json').write_text(json_line(manifest))
        await evaluate_cases(cases,products,tuple(args.strategies),report,embedder=embedder,vector_index=vector_index,reranker=reranker,
            recall_candidates=settings.recall_candidates,weights=tuple(params['rrf_weights']))
        return report
    finally:
        if vector_index is not None:await vector_index.close()
        if report['status']=='RUNNING':report['status']='FAILED'
        for name,result in report.get('strategies',{}).items():
            if result['status']=='RUNNING':report['strategies'][name]={'status':'FAILED'}
            elif result['status']=='PENDING':report['strategies'][name]={'status':'NOT_EXECUTED','reason':'earlier_stage_failed'}
        manifest['source_stable']=all(fingerprint(ROOT/name)==value for name,value in manifest['source_fingerprints'].items())
        manifest['data_stable']=all(fingerprint(Path(name))==value for name,value in manifest.get('data_fingerprints',{}).items())
        manifest['status']=report['status'] if manifest['source_stable'] and manifest['data_stable'] else 'INPUTS_CHANGED'
        report['status']=manifest['status']
        (args.output/'manifest.json').write_text(json_line(manifest))
        (args.output/'report.json').write_text(json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False)+'\n')
        (args.output/'failures.jsonl').write_text(''.join(json_line(row) for row in report['samples']
            if row['execution_errors'] or row['violations'] or row['empty_ok'] is False
            or any(value is not None and value<1 for value in row['metrics'].values())))
        lines=['# ESCI 开发档评测','','状态：'+report['status']+'；留出、中文派生集及策略冻结待执行。','',
            '| 组别 | 策略 | 站点 | 查询数 | 指标 |','|---|---|---|---|---|']
        for kind,strategies in report.get('summary',{}).items():
            for name,locales in strategies.items():
                for locale,values in locales.items():
                    lines.append(f'| {kind} | {name} | {locale} | {values["queries"]} | '+', '.join(f'{k}={v:.4f}' for k,v in values['metrics'].items())+' |')
        for name,result in report.get('strategies',{}).items():
            if result['status']=='NOT_EXECUTED':lines.append(f'\n{name}：未执行，原因 {result["reason"]}。')
        (args.output/'report.md').write_text('\n'.join(lines)+'\n')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--catalog',type=Path,default=ROOT/'data/catalog-esci-v1.jsonl.gz')
    parser.add_argument('--dataset-dir',type=Path,default=ROOT/'eval/esci')
    parser.add_argument('--strategies',nargs='+',choices=STRATEGIES,default=['keyword_2gram','bm25'])
    parser.add_argument('--index-dir',type=Path,default=ROOT/'data/esci-evaluation-vectors')
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();report=asyncio.run(run(args))
    print(json_line({'status':report['status'],'strategies':report['strategies']}).strip())
    raise SystemExit(0 if report['status']=='COMPLETED' else 1)


if __name__=='__main__':main()
