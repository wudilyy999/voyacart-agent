# -*- coding: utf-8 -*-
"""MainAgentOrchestrator

应用层编排入口：
    1. 把会话快照写入 ShoppingContext（ContextVar，工具与子 Agent 透明可读）；
    2. 长期记忆读路径：买家偏好经 PreferenceSelector 按本轮 query 相关性挑选后，
       有变化时随本轮输入注入一条 <buyer-preferences> hint 消息（dislike 不参与截断）；
    3. 消费 MainAgent 的 reply_stream 类型化事件流并映射到 TradeEventBus：
       TextBlockDeltaEvent → token.delta
       Task* 工具结果      → plan.update（从 AgentState.tasks_context 快照）
       （业务工具的 tool.invoke / tool.result 与 agent.dispatch 由工具自身发布）
    4. 上下文压缩检测：本轮结束后 AgentState.summary 发生变化即发布 context.compressed；
    5. 上游瞬时错误（限流/并发/5xx）有界重试；
    6. 结束后发布 final.result / error，落盘 AgentState，返回最终文本。

为何重试要放在这一层：2.0 模型层只对"建流阶段"的异常重试，而 OpenAI 兼容网关常把
限流错误写在 SSE 流中间（报 openai.APIError），此时已经走出模型层重试范围，不兜底就会
整轮失败。重试期间前端可能看到重复的流式片段，final.result 到达时会被覆盖。
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import time
from contextlib import AsyncExitStack, aclosing
from dataclasses import dataclass
from contextvars import ContextVar
from typing import Any, Awaitable, Callable, Optional

from agentscope.agent import Agent
from agentscope.event import (
    ReplyEndEvent,
    TextBlockDeltaEvent,
    ToolCallStartEvent,
    ToolResultEndEvent,
)
from agentscope.message import Msg, UserMsg

from app.application.agents.main_agent import SessionRegistry
from app.application.harness.drift_detector import DriftDetector
from app.application.harness.loop_detector import LoopDetector
from app.application.memory.preference_selector import (
    PreferenceSelector,
    material_exclusion_tags,
    render_preference_hint,
    render_preference_lines,
)
from app.domain.buyer.preference import PreferenceStore
from app.domain.session.ports.conversation_store import (
    ConversationEventRecord,
    ConversationStore,
    ConversationTurn,
)
from app.domain.session.ports.session_store import SessionStore  # noqa: F401 —— 保留类型引用
from app.infrastructure.cache.semantic_cache import SemanticCache
from app.infrastructure.context import ShoppingContext, ShoppingContextSnapshot
from app.infrastructure.eventbus import TradeEventBus
from app.infrastructure.budget import init_budget, remember_verified_result, get_budget, rule_fallback_text
from app.infrastructure.security.output_guard import audit_output
from app.infrastructure.transient import is_transient_error

from app.infrastructure.operational_metrics import begin_request, finish_request

logger = logging.getLogger(__name__)

# 内置 Task 计划工具名，其结果落地后向前端推送 plan.update 快照
_TASK_TOOL_NAMES = {"TaskCreate", "TaskUpdate", "TaskList", "TaskGet"}

# 上游瞬时故障判据与模型层共用同一份（app/infrastructure/transient.py），避免两处标记表漂移。
# 模型层已做一轮退避重试 + 备用模型回退，这里是最外层兜底：覆盖模型层之外
# （工具、子 Agent 调度、事件消费）招致的瞬时失败。
_MAX_TURN_RETRIES = 2
_RETRY_BASE_SECONDS = 6.0


@dataclass(frozen=True)
class SubmitIntentInput:
    shopping_session_id: str
    buyer_id: str
    locale: str
    currency: str
    raw_query: str


@dataclass(frozen=True)
class SubmitIntentOutput:
    shopping_session_id: str
    final_text: str
    error: str | None = None


def _tasks_snapshot(agent: Agent) -> dict:
    tasks = agent.state.tasks_context.tasks
    return {
        "tasks": [
            {"id": task.id, "subject": task.subject, "state": str(task.state)}
            for task in tasks
        ],
    }


class MainAgentOrchestrator:
    def __init__(
        self,
        sessions: SessionRegistry,
        bus: TradeEventBus,
        preference_store: PreferenceStore,
        conversation_store: Optional[ConversationStore] = None,
        semantic_cache: Optional[SemanticCache] = None,
        output_guard_enabled: bool = True,
        loop_detector: Optional[LoopDetector] = None,
        token_budget_total: int = 0,
        drift_detector: Optional[DriftDetector] = None,
        preference_selector: Optional[PreferenceSelector] = None,
        preference_top_k: int = 5,
        session_lease_factory: Callable[..., Any] | None = None,
        trade_state_provider: Callable[[str, str], Awaitable[dict]] | None = None,
        evidence_store: Any = None,
    ) -> None:
        self._evidence_store = evidence_store
        self._trade_state_provider = trade_state_provider
        self._session_lease_factory = session_lease_factory
        self._sessions = sessions
        self._bus = bus
        self._preference_store = preference_store
        self._conversation_store = conversation_store
        self._semantic_cache = semantic_cache
        self._output_guard_enabled = output_guard_enabled
        self._loop_detector = loop_detector
        self._token_budget_total = token_budget_total
        self._drift_detector = drift_detector
        # 默认 selector 不带 embedder，退化为“按时间倒序取 top_k”，单测与无凭据环境可直接跑
        self._preference_selector = preference_selector or PreferenceSelector()
        self._preference_top_k = preference_top_k
        # 会话内已注入的偏好快照，变化时才重新注入，避免每轮重复填充上下文
        self._injected_preferences: dict[str, str] = {}
        # 两种 HTTP 入口共用锁，防止同进程并发修改同一个 AgentState。
        self._session_locks: dict[str, asyncio.Lock] = {}
        self._native_observer: ContextVar[Callable[[Any], None] | None] = ContextVar(
            "voyacart_native_event_observer", default=None,
        )

    def _guard_final_text(self, session_id: str, text: str) -> str:
        """L4 输出审核：最终回复推给买家前脱敏内部信息。

        命中只脱敏并发一条告警事件，**不阻断回复**：
        一条误判不应让整轮对话失败。
        """
        if not self._output_guard_enabled or not text:
            return text
        safe, cleaned = audit_output(text)
        if not safe:
            logger.warning("L4 输出审核命中敏感内容，已脱敏（会话 %s）", session_id)
            self._bus.publish(session_id, "error", {"message": "输出审核命中内部信息，已脱敏后下发"})
        return cleaned

    async def handle_intent(
        self,
        intent: SubmitIntentInput,
        event_observer: Callable[[Any], None] | None = None,
        use_semantic_cache: bool = True,
        fresh_session: bool = False,
        persistence_guard: Callable[[], bool] | None = None,
    ) -> SubmitIntentOutput:
        lock = self._session_locks.setdefault(intent.shopping_session_id, asyncio.Lock())
        async with lock, AsyncExitStack() as stack:
            if self._session_lease_factory is not None:
                lease = await stack.enter_async_context(self._session_lease_factory(intent.shopping_session_id))
                caller_guard = persistence_guard
                persistence_guard = lambda: lease.is_valid() and (caller_guard is None or caller_guard())
                fresh_session = True
            if fresh_session:
                await self._sessions.invalidate(intent.shopping_session_id)
                self._injected_preferences.pop(intent.shopping_session_id, None)
            observer_token = self._native_observer.set(event_observer)
            metrics = begin_request()
            metrics_status = "error"
            try:
                result = await self._handle_intent(
                    intent, use_semantic_cache=use_semantic_cache, persistence_guard=persistence_guard,
                )
                metrics_status = "error" if result.error else "success"
                return result
            except asyncio.CancelledError:
                metrics_status = "cancelled"
                raise
            finally:
                self._native_observer.reset(observer_token)
                summary = finish_request(metrics, metrics_status)
                self._bus.publish(intent.shopping_session_id, "usage.summary", summary)

    async def _handle_intent(
        self, intent: SubmitIntentInput, *, use_semantic_cache: bool = True,
        persistence_guard: Callable[[], bool] | None = None,
    ) -> SubmitIntentOutput:
        session_id = intent.shopping_session_id
        snapshot = ShoppingContextSnapshot(
            shopping_session_id=session_id,
            buyer_id=intent.buyer_id,
            locale=intent.locale,
            currency=intent.currency,
        )
        token = ShoppingContext.set(snapshot)
        started_at = time.monotonic()
        # 本轮 Token 预算（TOKEN_BUDGET_TOTAL=0时为 None，不启用四档降级）
        init_budget(self._token_budget_total)
        if self._drift_detector is not None:
            self._drift_detector.start_turn(session_id, intent.raw_query)
        # 开始录事件轨迹（本轮结束后批量入库）
        trace = self._bus.subscribe(session_id) if self._conversation_store else None
        final_text = ""
        try:
            agent = await self._sessions.get_or_create(session_id)
            summary_before = agent.state.summary
            # 语义缓存：仅首轮（无历史上下文）且非写操作意图时尝试命中，命中则零模型调用
            has_history = bool(agent.state.context)
            trade_state = await self._trade_state_provider(intent.buyer_id, session_id) if self._trade_state_provider else {}
            remember_verified_result("trade", trade_state)
            has_trade_state = bool(trade_state.get("orders") or trade_state.get("pending_confirmations"))
            use_semantic_cache = use_semantic_cache and not has_trade_state
            cached = await self._lookup_cache(intent, has_history) if use_semantic_cache else None
            if cached is not None:
                final_text = self._guard_final_text(session_id, cached)
                self._bus.publish(session_id, "final.result", {"text": final_text})
                return SubmitIntentOutput(shopping_session_id=session_id, final_text=final_text)

            # 每轮用持久偏好重建权威提示；从模型上下文移除旧提示，避免撤回后旧提示复活。
            agent.state.context[:] = [m for m in agent.state.context if m.name not in {"memory_hint", "trade_state", "candidate_state"}]
            inputs = await self._build_inputs(intent, session_id)
            if self._evidence_store is not None:
                candidates = await self._evidence_store.search(intent.buyer_id, session_id, kind="products", limit=1)
                if candidates:
                    latest = candidates[0]
                    candidate_hint = {"result_ref": latest["result_ref"], "historical": True,
                        "candidates": [{"position": i+1, "product_id": p["product_id"], "title": p["title"]}
                                       for i, p in enumerate(latest["data"].get("hits", []))]}
                    inputs.insert(0, UserMsg("candidate_state", "最近一次候选的稳定顺序，用于理解‘第二个’等指代；新检索会替换此顺序。当前库存、价格和订单状态仍需工具核验。\n" + json.dumps(candidate_hint, ensure_ascii=False)))
            if has_trade_state:
                hint = UserMsg("trade_state", "以下是本轮从服务端账本恢复的交易事实，以此为准核对历史；待确认不等于已执行，不能代用户批准。\n"
                               + json.dumps(trade_state, ensure_ascii=False))
                inputs.insert(0, hint)

            final_text = await self._reply_with_retry(session_id, agent, inputs)
            final_text = self._guard_final_text(session_id, final_text)
            await self._check_drift(session_id)

            self._publish_compression(session_id, agent, summary_before)
            self._bus.publish(session_id, "final.result", {"text": final_text})
            if use_semantic_cache:
                await self._remember_cache(intent, final_text, has_history)
            return SubmitIntentOutput(shopping_session_id=session_id, final_text=final_text)
        except asyncio.CancelledError:
            # 断开 SSE 连接会取消本轮；保留中断事实，不能继续后台生成或记成成功。
            final_text = "[cancelled] 本轮执行已中断"
            self._bus.publish(session_id, "error", {"message": "本轮执行已中断", "cancelled": True})
            raise
        except Exception as err:  # noqa: BLE001 —— 兜底转事件，避免长任务静默失败
            budget = get_budget()
            if budget is not None and budget.fallback_used:
                # SDK 的摘要工具模式可能拒绝规则文本；退出摘要流程后仍给出确定的规则结果。
                final_text = self._guard_final_text(session_id, rule_fallback_text())
                self._bus.publish(session_id, "final.result", {"text": final_text, "budget_fallback": True})
                return SubmitIntentOutput(shopping_session_id=session_id, final_text=final_text)
            logger.exception("MainAgent 异常")
            self._bus.publish(session_id, "error", {"message": str(err)})
            final_text = f"[error] {err}"
            return SubmitIntentOutput(shopping_session_id=session_id, final_text=final_text, error=str(err))
        finally:
            try:
                # 租约有效性只是快速拦截；持久 store 在事务内以 fence/revision 拒绝旧写。
                if persistence_guard is None or persistence_guard():
                    persisted = await self._sessions.persist(session_id)
                    if persisted is not False and (persistence_guard is None or persistence_guard()):
                        await self._record_conversation(intent, final_text, int((time.monotonic() - started_at) * 1000), trace)
                        if self._evidence_store is not None:
                            await self._evidence_store.save(intent.buyer_id, session_id, "conversation", {"buyer": intent.raw_query, "agent": final_text})
                else:
                    await self._sessions.invalidate(session_id)
                    self._injected_preferences.pop(session_id, None)
            finally:
                if trace is not None:
                    self._bus.unsubscribe(session_id, trace)
                if self._loop_detector is not None:
                    self._loop_detector.reset(session_id)
                if self._drift_detector is not None:
                    self._drift_detector.reset(session_id)
                ShoppingContext.reset(token)

    async def _preference_scope(self, buyer_id: str) -> str | None:
        """买家当前偏好的指纹，作为语义缓存的分桶维度。

        用**全量偏好**而不是本轮选中的子集：选中子集随 query 变，拿它做 key
        会让缓存碎成一盘沙。全量偏好只在真正新增/撤回时变，恰好是正确的失效时机。
        """
        try:
            preferences = await self._preference_store.list_by_buyer(buyer_id)
        except Exception as err:  # noqa: BLE001
            logger.warning("读取偏好指纹失败，本轮跳过缓存：%s", type(err).__name__)
            return None
        if not preferences:
            return ""
        return hashlib.sha256(
            render_preference_lines(preferences).encode(),
        ).hexdigest()[:16]

    async def _lookup_cache(self, intent: SubmitIntentInput, has_history: bool) -> Optional[str]:
        """语义缓存查询；命中时发 cache.hit 事件让过程可见（不静默复用）。"""
        if self._semantic_cache is None:
            return None
        scope = await self._preference_scope(intent.buyer_id)
        if scope is None:
            return None
        hit = await self._semantic_cache.lookup(
            intent.buyer_id,
            intent.raw_query,
            has_history,
            scope=scope,
        )
        if hit is None:
            return None
        logger.info("语义缓存命中（%.4f）：%s", hit.similarity, intent.raw_query)
        self._bus.publish(
            intent.shopping_session_id,
            "cache.hit",
            {"similarity": hit.similarity, "matched_query": hit.matched_query},
        )
        return hit.reply

    async def _remember_cache(
        self, intent: SubmitIntentInput, final_text: str, has_history: bool,
    ) -> None:
        if self._semantic_cache is None:
            return
        scope = await self._preference_scope(intent.buyer_id)
        if scope is None:
            return
        await self._semantic_cache.remember(
            intent.buyer_id,
            intent.raw_query,
            final_text,
            has_history,
            scope=scope,
        )

    async def _record_conversation(
        self,
        intent: SubmitIntentInput,
        final_text: str,
        latency_ms: int,
        trace: Optional[asyncio.Queue],
    ) -> None:
        """对话流水 + 事件轨迹入库。写库失败只告警，不影响已经返回给买家的结果。"""
        if self._conversation_store is None:
            return
        session_id = intent.shopping_session_id
        events: list[ConversationEventRecord] = []
        if trace is not None:
            self._bus.unsubscribe(session_id, trace)
            while not trace.empty():
                event = trace.get_nowait()
                # token.delta 量大且已被 final.result 汇总，不入库
                if event.type == "token.delta":
                    continue
                events.append(
                    ConversationEventRecord(
                        session_id=session_id,
                        type=event.type,
                        payload=event.payload if isinstance(event.payload, dict) else {"value": event.payload},
                        occurred_at=event.occurred_at,
                    ),
                )
        try:
            await self._conversation_store.touch_session(
                session_id, intent.buyer_id, intent.locale, intent.currency,
            )
            await self._conversation_store.append_turn(
                ConversationTurn(
                    session_id=session_id,
                    buyer_id=intent.buyer_id,
                    role="buyer",
                    content=intent.raw_query,
                ),
            )
            await self._conversation_store.append_turn(
                ConversationTurn(
                    session_id=session_id,
                    buyer_id=intent.buyer_id,
                    role="agent",
                    content=final_text,
                    latency_ms=latency_ms,
                ),
            )
            await self._conversation_store.append_events(events)
        except Exception as err:  # noqa: BLE001
            logger.warning("对话记录写入失败：%s（%s）", session_id, err)

    async def _reply_with_retry(self, session_id: str, agent: Agent, inputs: list[Msg]) -> str:
        """跑一轮 Agent 并映射事件流；上游瞬时错误按指数退避重试。"""
        last_error: Exception | None = None
        for attempt in range(_MAX_TURN_RETRIES + 1):
            try:
                return await self._consume_reply(session_id, agent, inputs)
            except Exception as err:  # noqa: BLE001
                if not is_transient_error(err) or attempt >= _MAX_TURN_RETRIES:
                    raise
                last_error = err
                # 指数退避：网关速率类限流对固定间隔重试不敏感
                delay = _RETRY_BASE_SECONDS * (3**attempt)
                logger.warning(
                    "上游瞬时故障，%.0fs 后重试（第 %d/%d 次）：%s",
                    delay,
                    attempt + 1,
                    _MAX_TURN_RETRIES,
                    err,
                )
                self._bus.publish(
                    session_id,
                    "error",
                    {"message": f"上游瞬时故障，正在重试：{err}", "retrying": True},
                )
                # 重试时不再重复送入 inputs，避免上下文里出现两次买家发言
                inputs = []
                await asyncio.sleep(delay)
        raise last_error if last_error else RuntimeError("reply 重试耗尽")

    async def _consume_reply(self, session_id: str, agent: Agent, inputs: list[Msg]) -> str:
        final_text = ""
        interrupted = False
        reply_error: str | None = None
        # tool_call_id → 工具名，用于把 ToolResultEndEvent 关联回 Task 工具
        call_names: dict[str, str] = {}
        async with aclosing(agent.reply_stream(inputs or None, yield_final_msg=True)) as events:
            async for event in events:
                observer = self._native_observer.get()
                if observer is not None:
                    observer(event)
                if isinstance(event, Msg):
                    final_text = event.get_text_content() or ""
                elif isinstance(event, ReplyEndEvent):
                    # AgentScope 可吞掉 CancelledError 并改发结束事件，仍需向 HTTP 层传播中断。
                    reason = str(event.finished_reason).lower()
                    interrupted = reason == "interrupted"
                    if reason in {"error", "exceed_max_iters"}:
                        reply_error = "Agent 本轮执行失败" if reason == "error" else "Agent 超出本轮执行步数上限"
                elif isinstance(event, TextBlockDeltaEvent):
                    if event.delta:
                        self._bus.publish(
                            session_id,
                            "token.delta",
                            {"name": agent.name, "token": event.delta},
                        )
                elif isinstance(event, ToolCallStartEvent):
                    call_names[event.tool_call_id] = event.tool_call_name
                elif isinstance(event, ToolResultEndEvent):
                    tool_name = call_names.get(event.tool_call_id)
                    if tool_name in _TASK_TOOL_NAMES:
                        self._bus.publish(session_id, "plan.update", _tasks_snapshot(agent))
                    self._observe_for_drift(session_id, tool_name, event)
        if interrupted:
            raise asyncio.CancelledError()
        if reply_error:
            raise RuntimeError(reply_error)
        return final_text

    def _observe_for_drift(self, session_id: str, tool_name: Optional[str], event: Any) -> None:
        """把一次工具结果记进漂移轨迹（开关关时零开销）。"""
        if self._drift_detector is None or not tool_name:
            return
        text = ""
        try:
            blocks = getattr(event, "output", None) or []
            text = "\n".join(
                str(getattr(block, "text", "") or (block.get("text", "") if isinstance(block, dict) else ""))
                for block in blocks
            )
        except Exception:  # noqa: BLE001 —— 观测不能影响主链路
            text = ""
        # “无候选”的判据：检索类工具返回的 hits 为空
        result_empty = bool(text) and ('"hits": []' in text or '"hits":[]' in text)
        self._drift_detector.observe_action(
            session_id, f"{tool_name} {text[:200]}", result_empty=result_empty,
        )

    async def _check_drift(self, session_id: str) -> None:
        """轮末漂移判定：命中只发事件 + 记日志。

        不在这里改写回复——本轮已结束，注入纠正提示已经来不及了；
        漂移信号的价值在于**被看见**（进事件流与 trace，供 bad case 回收）。
        """
        if self._drift_detector is None:
            return
        try:
            report = await self._drift_detector.check(session_id)
        except Exception as err:  # noqa: BLE001
            logger.warning("漂移检测异常，忽略：%s", err)
            return
        if report.drifted:
            logger.warning("检测到静默漂移（会话 %s）：%s", session_id, report.reasons or report.verdict)
            self._bus.publish(
                session_id,
                "error",
                {
                    "message": "检测到可能的目标漂移",
                    "reasons": report.reasons,
                    "verdict": report.verdict,
                },
            )

    def _publish_compression(self, session_id: str, agent: Agent, summary_before: str | None) -> None:
        """上下文压缩发生时，2.0 会把早期消息压成摘要写入 AgentState.summary，
        比对本轮前后的 summary 即可判定并上报。"""
        summary_after = agent.state.summary
        if not summary_after or summary_after == summary_before:
            return
        self._bus.publish(
            session_id,
            "context.compressed",
            {
                "summary_length": len(summary_after),
                "context_messages": len(agent.state.context),
            },
        )

    async def _build_inputs(self, intent: SubmitIntentInput, session_id: str) -> list[Msg]:
        """长期记忆读路径：偏好有变化时随本轮输入注入 hint 消息。"""
        user_msg = UserMsg(intent.buyer_id, intent.raw_query)
        try:
            preferences = await self._preference_store.list_by_buyer(intent.buyer_id)
        except Exception as err:  # noqa: BLE001
            raise RuntimeError("当前偏好读取失败，无法可靠核对买家硬约束，请稍后重试") from err
        revision = hashlib.sha256(json.dumps([(p.kind, p.statement, p.created_at) for p in preferences], ensure_ascii=False).encode()).hexdigest()
        if self._evidence_store is not None:
            latest = await self._evidence_store.search(intent.buyer_id, session_id, kind="preferences", limit=1)
            if not latest or latest[0]["data"].get("revision") != revision:
                await self._evidence_store.save(intent.buyer_id, session_id, "preferences", {"revision": revision,
                    "preferences": [{"kind": p.kind, "statement": p.statement} for p in preferences]})
        if not preferences:
            self._injected_preferences[session_id] = revision
            return [UserMsg("memory_hint", f"当前持久偏好 revision={revision[:16]}：无。历史已撤回偏好不得恢复；本轮用户显式约束仍有效。"), user_msg]

        # 按与本轮 query 的相关性挑选：偏好越攒越多时，全量铺进去会把真正相关的那几条稀释。
        # dislike 不参与截断（见 PreferenceSelector 文档字符串）。
        selected = await self._preference_selector.select(
            preferences, query=intent.raw_query, top_k=self._preference_top_k,
        )
        if not selected:
            return [user_msg]

        ShoppingContext.set_excluded_material_tags(material_exclusion_tags(selected))
        rendered = render_preference_lines(selected)
        self._injected_preferences[session_id] = rendered
        hint_msg = UserMsg("memory_hint", f"当前持久偏好 revision={revision[:16]}，覆盖历史摘要中的旧偏好。\n" + render_preference_hint(selected))
        return [hint_msg, user_msg]
