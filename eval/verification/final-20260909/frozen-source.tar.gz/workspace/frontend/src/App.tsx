import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useCommerceAgent } from "./hooks/useCommerceAgent";
import { readProducts } from "./lib/commerceClient";
import type { ProductCard } from "./types";
import Icon from "./components/Icon";
import Markdown from "./components/Markdown";
import EventTimeline from "./components/EventTimeline";
import ProductCards, { ProductImage } from "./components/ProductCards";
import ProductDetail from "./components/ProductDetail";
import ConfirmationCards from "./components/ConfirmationCards";
import OrderIntentForm from "./components/OrderIntentForm";
import ProductComparison from "./components/ProductComparison";

type View = "shopping" | "history" | "favorites";
const STARTERS = [
  "预算300元以内，找一个轻便的周末旅行背包，寄到中国。",
  "想买日常通勤耳机，帮我理一理选购思路。",
  "预算100元以内，找适合短途出行的背包。",
];
const FAVORITES_KEY = "voyacart.favorites.v1";
function readFavorites(): ProductCard[] {
  try {
    const data: unknown = JSON.parse(
      localStorage.getItem(FAVORITES_KEY) || "[]",
    );
    return readProducts(data).slice(0, 100);
  } catch {
    return [];
  }
}

export default function App() {
  const agent = useCommerceAgent();
  const [view, setView] = useState<View>("shopping"),
    [input, setInput] = useState("");
  const [favorites, setFavorites] = useState<ProductCard[]>(readFavorites),
    [compared, setCompared] = useState<ProductCard[]>([]);
  const [detail, setDetail] = useState<ProductCard | null>(null),
    [showCompare, setShowCompare] = useState(false),
    [toast, setToast] = useState("");
  const [orderIntent, setOrderIntent] = useState<{
    product: ProductCard;
    skuId: string;
  } | null>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null),
    bottomRef = useRef<HTMLDivElement>(null),
    autoScroll = useRef(true),
    programmaticScroll = useRef(false);
  const busy = agent.status === "running";
  const favoriteIds = useMemo(
    () => new Set(favorites.map((p) => p.product_id)),
    [favorites],
  );
  const comparedIds = useMemo(
    () => new Set(compared.map((p) => p.product_id)),
    [compared],
  );
  const lastUser = [...agent.messages]
    .reverse()
    .find((message) => message.role === "user");
  const landedDestination = agent.products.find(
    (product) => product.landed_price?.ship_to,
  )?.landed_price?.ship_to;

  useEffect(() => {
    try {
      localStorage.setItem(FAVORITES_KEY, JSON.stringify(favorites));
    } catch {
      setToast("浏览器暂时无法保存收藏，本次使用仍可继续。 ");
    }
  }, [favorites]);
  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 2600);
    return () => window.clearTimeout(timer);
  }, [toast]);
  useEffect(() => {
    setCompared([]);
    setDetail(null);
    setOrderIntent(null);
    setShowCompare(false);
  }, [agent.sessionId]);
  useEffect(() => {
    let previousY = window.scrollY;
    const onScroll = () => {
      const currentY = window.scrollY;
      const distance =
        document.documentElement.scrollHeight - currentY - window.innerHeight;
      if (!programmaticScroll.current) {
        // 用户向上查看历史即暂停跟随，不要求先滚出某个距离。
        if (currentY < previousY - 1 || distance > 240)
          autoScroll.current = false;
        else if (currentY > previousY && distance < 28)
          autoScroll.current = true;
      }
      previousY = currentY;
    };
    const onWheel = (event: WheelEvent) => {
      if (event.deltaY < 0) autoScroll.current = false;
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("wheel", onWheel, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("wheel", onWheel);
    };
  }, []);
  useEffect(() => {
    if (
      view !== "shopping" ||
      detail ||
      showCompare ||
      !autoScroll.current ||
      !agent.messages.length
    )
      return;
    let releaseFrame = 0;
    const frame = requestAnimationFrame(() => {
      if (!autoScroll.current) return;
      programmaticScroll.current = true;
      bottomRef.current?.scrollIntoView({ block: "end", behavior: "auto" });
      releaseFrame = requestAnimationFrame(() => {
        programmaticScroll.current = false;
      });
    });
    return () => {
      cancelAnimationFrame(frame);
      cancelAnimationFrame(releaseFrame);
      programmaticScroll.current = false;
    };
  }, [agent.messages, agent.products, view, detail, showCompare]);

  const submit = useCallback(
    (query: string) => {
      if (!query.trim() || busy) return;
      setView("shopping");
      setInput("");
      setCompared([]);
      setShowCompare(false);
      autoScroll.current = true;
      void agent.submit(query.trim());
    },
    [agent.submit, busy],
  );
  const newShopping = () => {
    agent.reset();
    setView("shopping");
    setInput("");
    autoScroll.current = true;
    window.scrollTo({ top: 0 });
    inputRef.current?.focus();
  };
  const openSession = (id: string) => {
    agent.setSession(id);
    setView("shopping");
    window.scrollTo({ top: 0 });
  };
  const switchView = (next: View) => {
    setView(next);
    window.scrollTo({ top: 0 });
  };
  const toggleFavorite = useCallback(
    (product: ProductCard) => {
      if (favoriteIds.has(product.product_id)) {
        setFavorites((current) =>
          current.filter((item) => item.product_id !== product.product_id),
        );
        setToast("已从心选收藏移除。");
      } else {
        setFavorites((current) => [product, ...current].slice(0, 100));
        setToast("已收好，喜欢的可以慢慢选。 ");
      }
    },
    [favoriteIds],
  );
  const toggleCompare = useCallback(
    (product: ProductCard) => {
      if (comparedIds.has(product.product_id))
        setCompared((current) =>
          current.filter((item) => item.product_id !== product.product_id),
        );
      else if (compared.length >= 3)
        setToast("一次可以比较 3 件商品，先移出一件再试试。 ");
      else setCompared((current) => [...current, product]);
    },
    [comparedIds, compared.length],
  );
  const upsertCompare = useCallback(
    (product: ProductCard) => {
      if (!comparedIds.has(product.product_id) && compared.length >= 3) {
        setToast("一次可以比较 3 件商品，先移出一件再试试。 ");
        return;
      }
      // 详情选择规格是新增或更新；只有商品卡复选框负责移除比较。
      setCompared((current) =>
        current.some((item) => item.product_id === product.product_id)
          ? current.map((item) =>
              item.product_id === product.product_id ? product : item,
            )
          : current.length < 3
            ? [...current, product]
            : current,
      );
      setToast("已按当前所选规格更新比较信息。 ");
    },
    [comparedIds, compared.length],
  );
  const renderCards = (products: ProductCard[]) => (
    <ProductCards
      products={products}
      favoriteIds={favoriteIds}
      comparedIds={comparedIds}
      onFavorite={toggleFavorite}
      onCompare={toggleCompare}
      onDetail={setDetail}
    />
  );
  const navItems: { id: View; label: string; icon: string }[] = [
    { id: "shopping", label: "我的选购", icon: "bag" },
    { id: "history", label: "对话历史", icon: "chat" },
    { id: "favorites", label: "心选收藏", icon: "heart" },
  ];

  return (
    <>
      <aside className="sidebar" aria-label="主导航">
        <button
          className="brand"
          onClick={() => switchView("shopping")}
          aria-label="Voyacart 环球好物首页"
        >
          <Icon name="globe" className="brand-mark" />
          <span>
            <span className="brand-name">Voyacart</span>
            <span className="brand-subtitle">环球好物</span>
          </span>
        </button>
        <button className="new-chat" onClick={newShopping} disabled={busy}>
          <Icon name="plus" />
          开启一次新选购
        </button>
        <nav className="nav">
          {navItems.map((item) => (
            <button
              key={item.id}
              className={`nav-item ${view === item.id ? "active" : ""}`}
              onClick={() => switchView(item.id)}
              aria-current={view === item.id ? "page" : undefined}
            >
              <Icon name={item.icon} />
              {item.label}
              {item.id === "favorites" && (
                <span className="nav-count">{favorites.length}</span>
              )}
            </button>
          ))}
        </nav>
        <div className="nav-label">最近选购</div>
        {agent.history.slice(0, 4).map((item) => (
          <button
            className="history-short"
            key={item.id}
            onClick={() => openSession(item.id)}
            disabled={busy}
            title={item.title}
          >
            {item.title}
          </button>
        ))}
        {!agent.history.length && (
          <p className="sidebar-empty">第一段选购，等你开启。</p>
        )}
        <div className="sidebar-bottom">
          <div className="sidebar-note">
            <Icon name="globe" className="little-orbit" />
            <p>
              世界很大，
              <br />
              适合你的，刚刚好。
            </p>
          </div>
          <div className="profile">
            <span className="avatar">旅</span>
            <span>
              <span className="profile-name">好物探索家</span>
              <span className="profile-caption">每一次选择，都有新发现</span>
            </span>
            <Icon name="leaf" />
          </div>
        </div>
      </aside>
      <main>
        <div className="content">
          <header className="topbar">
            <div className="breadcrumb">
              <span>环球好物</span>
              <span>／</span>
              <span>
                {view === "history"
                  ? "选购对话历史"
                  : view === "favorites"
                    ? "心选收藏"
                    : "为你挑选"}
              </span>
            </div>
            <button
              className="mobile-brand"
              onClick={() => switchView("shopping")}
            >
              <Icon name="globe" />
              Voyacart
            </button>
            <div className="location">
              <Icon name="pin" />
              {landedDestination
                ? `配送至 ${landedDestination}`
                : "好物，跨越距离"}
            </div>
          </header>
          <nav className="mobile-nav" aria-label="移动导航">
            <button onClick={newShopping} disabled={busy}>
              新选购
            </button>
            {navItems.map((item) => (
              <button
                key={item.id}
                className={view === item.id ? "active" : ""}
                onClick={() => switchView(item.id)}
              >
                {item.label}
              </button>
            ))}
          </nav>
          {view === "shopping" && (
            <>
              <section className="hero">
                <div className="eyebrow">A LITTLE LESS, A LITTLE BETTER</div>
                <h1>
                  为下一次出发，<em>选得刚刚好。</em>
                </h1>
                <p>说说你的期待。世界各地的好物，我陪你慢慢选。</p>
              </section>
              {!agent.messages.length ? (
                <section className="welcome-panel">
                  <Icon name="globe" className="welcome-orbit" />
                  <h2>下一件好物，你想找什么？</h2>
                  <p>从一个用途、一段旅程，或一个小偏好聊起。</p>
                  <div className="welcome-ideas">
                    <button onClick={() => submit(STARTERS[0])}>
                      周末出游，轻便背包
                      <Icon name="arrow" />
                    </button>
                    <button onClick={() => submit(STARTERS[1])}>
                      通勤路上的好声音
                      <Icon name="arrow" />
                    </button>
                    <button onClick={() => submit(STARTERS[2])}>
                      预算 100 元以内
                      <Icon name="arrow" />
                    </button>
                  </div>
                  <span className="welcome-caption">
                    每一份推荐，都从你的实际需求开始。
                  </span>
                </section>
              ) : (
                <section className="conversation" aria-label="选购对话">
                  {agent.messages.map((message, index) =>
                    message.role === "user" ? (
                      <div className="query-row" key={message.id}>
                        <div className="query-bubble">{message.content}</div>
                      </div>
                    ) : (
                      <div className="assistant-row" key={message.id}>
                        <div className="assistant-mark">
                          <Icon name="spark" />
                        </div>
                        <div
                          className={`assistant-text ${busy && index === agent.messages.length - 1 ? "typing" : ""}`}
                        >
                          <Markdown
                            content={message.content}
                            streaming={
                              busy && index === agent.messages.length - 1
                            }
                          />
                        </div>
                      </div>
                    ),
                  )}
                </section>
              )}
              {busy && (
                <div className="progress-line running" role="status">
                  <span className="live-dot" />
                  <span>{agent.step || "正在为你整理合适的选择…"}</span>
                </div>
              )}
              {agent.status === "stopped" && (
                <div className="progress-line stopped" role="status">
                  <Icon name="stop" />
                  <span>
                    {agent.recoverableRunId ? "停止请求已发送，正在等待服务端确认。已有内容已保留。" : "已停止本次回复。已有内容为你保留，可以继续补充需求。"}
                  </span>
                </div>
              )}
              {agent.error && (
                <div className="error-panel" role="alert">
                  <Icon name="info" />
                  <div>
                    <strong>暂时没能完成这次选购</strong>
                    <p>{agent.error}</p>
                  </div>
                  {agent.recoverableRunId ? (
                    <>
                      <button disabled={busy} onClick={() => void agent.resume()}>恢复本轮</button>
                      <button disabled={busy} onClick={agent.stop}>停止本轮</button>
                    </>
                  ) : lastUser && (
                    <button
                      disabled={busy}
                      onClick={() => submit(lastUser.content)}
                    >
                      再试一次
                    </button>
                  )}
                </div>
              )}
              {(agent.confirmations.length > 0 || agent.confirmationError) && (
                <ConfirmationCards
                  confirmations={agent.confirmations}
                  busy={agent.confirmationBusy || busy}
                  error={agent.confirmationError}
                  onResolve={agent.resolveConfirmation}
                  onCancelOrder={agent.prepareCancel}
                  onRefresh={agent.refreshConfirmations}
                />
              )}
              {agent.products.length > 0 && (
                <section className="search-results" aria-label="商品搜索结果">
                  <div className="results-heading">
                    <div className="results-label">
                      <strong>这次找到的好物</strong> · {agent.products.length}{" "}
                      件
                    </div>
                    <button
                      className="results-action"
                      onClick={() =>
                        setToast(
                          "勾选商品卡下方的“加入比较”，可并排比较 2 至 3 件商品。 ",
                        )
                      }
                    >
                      <Icon name="compare" />
                      勾选商品，轻松对比
                    </button>
                  </div>
                  {renderCards(agent.products)}
                  <div className="results-footnote">
                    <Icon name="info" />
                    <span>
                      结果来自商品目录。示意图与样例评分均已标注，价格以具体规格及配送条件为准。
                    </span>
                  </div>
                </section>
              )}
              {!busy &&
                agent.searchCompleted &&
                !agent.products.length &&
                !agent.error && (
                  <section className="empty-state search-empty">
                    <Icon name="bag" />
                    <h2>
                      {agent.status === "stopped"
                        ? "先停在这里，也没关系"
                        : "这次，还没有合适的结果"}
                    </h2>
                    <p>
                      {agent.status === "stopped"
                        ? "本轮已停止，尚未收到商品结果。调整需求后可以重新开始。"
                        : "这次检索没有返回符合条件的商品。可以调整预算、品类或配送地区，再一起看看。"}
                    </p>
                    <button
                      onClick={() => {
                        setInput(lastUser?.content || "");
                        inputRef.current?.focus();
                      }}
                    >
                      调整一下需求
                      <Icon name="arrow" />
                    </button>
                  </section>
                )}
              {busy && !agent.products.length && (
                <div
                  className="product-grid loading-results"
                  aria-label="正在查找商品"
                >
                  <div className="loading-card" />
                  <div className="loading-card" />
                  <div className="loading-card" />
                </div>
              )}
              {agent.messages.length > 0 && (
                <div className="suggestions">
                  <button
                    className="suggestion"
                    disabled={busy}
                    onClick={() => {
                      setInput("预算想再少一点，");
                      inputRef.current?.focus();
                    }}
                  >
                    调整预算
                    <Icon name="arrow" />
                  </button>
                  {agent.products.length > 1 && (
                    <button
                      className="suggestion"
                      onClick={() => {
                        setCompared(agent.products.slice(0, 3));
                        setShowCompare(true);
                      }}
                    >
                      一起比较看看
                      <Icon name="compare" />
                    </button>
                  )}
                  <button
                    className="suggestion"
                    onClick={() => switchView("favorites")}
                  >
                    看看我的收藏
                    <Icon name="heart" />
                  </button>
                </div>
              )}
              <EventTimeline events={agent.events} />
              <div ref={bottomRef} className="scroll-anchor" />
            </>
          )}
          {view === "favorites" && (
            <>
              <h1 className="library-title">心动的，先留在这里。</h1>
              <p className="library-description">
                收藏保存在本机浏览器。以下是上次查看的商品信息，价格与库存请重新查询确认。
              </p>
              {favorites.length ? (
                renderCards(favorites)
              ) : (
                <section className="empty-state">
                  <Icon name="heart" />
                  <h2>等待第一份心动</h2>
                  <p>点击商品右上角的爱心，就能把喜欢的留在这里。</p>
                  <button onClick={() => switchView("shopping")}>
                    去发现好物
                    <Icon name="arrow" />
                  </button>
                </section>
              )}
            </>
          )}
          {view === "history" && (
            <>
              <h1 className="library-title">每一次期待，都有迹可循。</h1>
              <p className="library-description">
                同一买家身份的选购记录由服务端保存，断线后可恢复。浏览器另保留最近 12 段缓存；本机收藏与身份信息仍需自行保留。
              </p>
              {agent.historyError && <p role="status">{agent.historyError}</p>}
              <div className="history-list">
                {agent.history.length ? (
                  agent.history.map((item) => (
                    <button
                      key={item.id}
                      className="history-entry"
                      onClick={() => openSession(item.id)}
                      disabled={busy}
                    >
                      <span className="history-icon">
                        <Icon name="chat" />
                      </span>
                      <span>
                        <strong>{item.title}</strong>
                        <small>
                          {new Date(item.updatedAt).toLocaleString("zh-CN")}
                          {item.id === agent.sessionId ? " · 当前选购" : ""}
                        </small>
                      </span>
                      <Icon name="arrow" />
                    </button>
                  ))
                ) : (
                  <section className="empty-state">
                    <Icon name="chat" />
                    <h2>从第一次选购开始</h2>
                    <p>你和 Voyacart 的每次交流，会为下一次选择留下一点线索。</p>
                    <button onClick={newShopping}>
                      开启新的选购
                      <Icon name="arrow" />
                    </button>
                  </section>
                )}
              </div>
            </>
          )}
        </div>
      </main>
      <div className="composer-dock">
        <div className="composer-wrap">
          {compared.length > 0 && (
            <div className="compare-bar">
              <div className="compare-mini">
                {compared.map((p) => (
                  <ProductImage product={p} key={p.product_id} />
                ))}
              </div>
              <span>
                已选 {compared.length} 件
                {compared.length === 1 ? "，再选一件比比看" : ""}
              </span>
              <button
                className="compare-go"
                onClick={() => setShowCompare(true)}
                disabled={compared.length < 2}
              >
                开始比较
                <Icon name="arrow" />
              </button>
              <button className="compare-clear" onClick={() => setCompared([])}>
                清空
              </button>
            </div>
          )}
          <form
            className="composer"
            onSubmit={(event) => {
              event.preventDefault();
              if (busy) agent.stop();
              else submit(input);
            }}
          >
            <label htmlFor="query" className="sr-only">
              告诉 Voyacart 你想寻找的好物
            </label>
            <textarea
              ref={inputRef}
              id="query"
              value={input}
              rows={1}
              maxLength={4000}
              placeholder="再聊聊你的偏好，让选择更接近你…"
              onChange={(event) => setInput(event.target.value)}
              onKeyDown={(event) => {
                if (
                  event.key === "Enter" &&
                  !event.shiftKey &&
                  !event.nativeEvent.isComposing
                ) {
                  event.preventDefault();
                  if (!busy) submit(input);
                }
              }}
            />
            <div className="composer-bottom">
              <span className="composer-hint">
                <Icon name="spark" />
                告诉我用途、预算，或你在意的小细节
              </span>
              <button
                type="submit"
                className={`send-button ${busy ? "stop" : ""}`}
                disabled={!busy && !input.trim()}
                aria-label={busy ? "停止生成" : "发送选购需求"}
              >
                <Icon name={busy ? "stop" : "up"} />
                {busy && <span>停止</span>}
              </button>
            </div>
          </form>
          <footer className="preview-footer">
            <span>Voyacart 环球好物</span>
            <span>·</span>
            <span>认真挑选，从容决定</span>
          </footer>
        </div>
      </div>
      {detail && (
        <ProductDetail
          key={detail.product_id}
          product={detail}
          busy={busy}
          onClose={() => setDetail(null)}
          onCompare={upsertCompare}
          onAsk={submit}
          onPrepare={(product, skuId) => {
            setDetail(null);
            setOrderIntent({ product, skuId });
          }}
        />
      )}
      {orderIntent && (
        <OrderIntentForm
          product={orderIntent.product}
          skuId={orderIntent.skuId}
          busy={agent.confirmationBusy}
          error={agent.confirmationError}
          onClose={() => setOrderIntent(null)}
          onPrepare={async (input) => {
            const success = await agent.prepareOrder(input);
            if (success) {
              setView("shopping");
              setToast("确认单已准备好，请核对后决定。");
            }
            return success;
          }}
        />
      )}
      {showCompare && compared.length >= 2 && (
        <ProductComparison
          products={compared}
          onClose={() => setShowCompare(false)}
        />
      )}
      <div className={`toast ${toast ? "visible" : ""}`} role="status">
        {toast}
      </div>
    </>
  );
}
